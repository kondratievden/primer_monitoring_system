import {createApp} from 'vue';
import App from "@/components/App";

createApp(App).mount('#app')

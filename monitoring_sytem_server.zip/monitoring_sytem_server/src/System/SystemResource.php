<?php

namespace SaeedVaziry\Monitoring\System;

interface SystemResource
{
    /**
     * @return mixed
     */
    public function usage();
}
